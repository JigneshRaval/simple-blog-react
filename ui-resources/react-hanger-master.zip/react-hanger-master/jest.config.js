module.exports = {
  transform: {
    '^.+\\.(ts|tsx)$': 'ts-jest',
  },
};
