import React from 'react';

const Books = () => {
    return (
        <div className="jumbotron">
            <h1 className="display-3">My Books</h1>
        </div>
    );
}

export default Books;