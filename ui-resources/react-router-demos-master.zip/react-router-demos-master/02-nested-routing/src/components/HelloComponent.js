import React from 'react';

const Hello = () => {
    return (
        <div className="jumbotron">
            <h1 className="display-3">Hello, world!</h1>
        </div>
    );
}

export default Hello;