import React from 'react';

const Home = () => {
    return (
        <div className="jumbotron">
            <h1 className="display-3">Landing page</h1>
        </div>
    );
}

export default Home;